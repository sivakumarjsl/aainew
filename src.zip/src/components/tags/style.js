import Styled from 'styled-components';
import { Tag } from 'antd';

const TagStyle = Styled(Tag)`

`;

export { TagStyle };
