import Styled from 'styled-components';
import { Drawer } from 'antd';

const DrawerStyle = Styled(Drawer)`

`;

export { DrawerStyle };
