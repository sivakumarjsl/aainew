import Styled from 'styled-components';

const H1 = Styled.h1`
    color: ${({ theme }) => theme['primary-color']}    
`;
export { H1 };
