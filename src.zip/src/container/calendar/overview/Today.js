import React from 'react';

const TodayCalendar = () => {
  return <div>Today</div>;
};

export default TodayCalendar;
